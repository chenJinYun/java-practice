package person.kim.regexandgame.game;

public abstract class Zombies implements Action{
	public abstract void appearance();
}
