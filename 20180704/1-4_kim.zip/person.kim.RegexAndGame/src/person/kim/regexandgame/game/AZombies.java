package person.kim.regexandgame.game;

public class AZombies extends Zombies {

	@Override
	public void action() {
		// TODO Auto-generated method stub

	}

	@Override
	public void attacks() {
		// TODO Auto-generated method stub

	}

	@Override
	public void appearance() {
		// TODO Auto-generated method stub

	}

}
