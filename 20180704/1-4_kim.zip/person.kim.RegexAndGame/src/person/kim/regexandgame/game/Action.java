package person.kim.regexandgame.game;

public interface Action {
	public void action();
	public void attacks();
}
