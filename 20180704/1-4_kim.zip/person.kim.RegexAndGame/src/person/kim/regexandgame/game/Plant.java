package person.kim.regexandgame.game;

public abstract class Plant implements Action{
	
	public abstract void appearance();
}
