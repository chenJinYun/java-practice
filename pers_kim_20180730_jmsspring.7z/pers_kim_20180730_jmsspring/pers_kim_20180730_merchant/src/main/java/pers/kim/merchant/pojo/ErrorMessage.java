package pers.kim.merchant.pojo;

/**
 * Create on 7/30/2018
 *
 * @Author Kim
 */
public class ErrorMessage {
    private int code;
    private String reson;

    public ErrorMessage() {
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getReson() {
        return reson;
    }

    public void setReson(String reson) {
        this.reson = reson;
    }
}
