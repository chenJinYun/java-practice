package pers.kim.merchant.dao;


import pers.kim.merchant.pojo.User;

/**
 * Create on 7/30/2018
 *
 * @Author Kim
 */
public interface UserDao {
    public User addUser(User user);
}
