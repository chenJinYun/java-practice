package util;

import java.text.SimpleDateFormat;

/**
 * Create by UserUtil on 7/11/2018
 */
public class UserUtil {

    public static SimpleDateFormat format;

    static {
        format = new SimpleDateFormat("yyyy-MM-dd");
    }

}
