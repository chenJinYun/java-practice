package httpservlet;

import datalist.User;
import usermanager.UserManager;
import usermanager.UserManagerImpl;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class UserServlet extends javax.servlet.http.HttpServlet {
    private String encoding;
    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        encoding=config.getInitParameter("encoding");
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//        super.doGet(req, resp);
        resp.getWriter().write(encoding);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//        super.doPost(req, resp);
        req.setCharacterEncoding(encoding);
        resp.setHeader("Content-Type","text/html;charset=utf-8");
        resp.setCharacterEncoding("UTF-8");
        SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd");
        String username= req.getParameter("username");
        String pwd= req.getParameter("pwd");
        String major= req.getParameter("major");
        String birth= req.getParameter("birth");
        User user=null;
        HttpSession session=req.getSession();//维持会话
        if((String) session.getAttribute("uname")==null){ //维持会话)
            try {
                session.setAttribute("user",new User(username,pwd,major,format.parse(birth)));
            } catch (ParseException e) {
                e.printStackTrace();
            }
            resp.sendRedirect("login.html");
            return;
        } else if(session.getAttribute("user")!=null) {
            user= (User) session.getAttribute("user");
            session.removeAttribute("user");
        }

        if((username!=null&&pwd!=null&&major!=null&&birth!=null)||user!=null){
            UserManager dp=new UserManagerImpl();
            User u=null;
            try {
                u=(user!=null)?user:new User(username,pwd,major,format.parse(birth));
            } catch (ParseException e) {
                e.printStackTrace();
            }
            dp.addUser(u);
            req.getRequestDispatcher("userforward").forward(req,resp);
        }else{
            resp.getWriter().write("请求参数错误！");
        }

    }
}
