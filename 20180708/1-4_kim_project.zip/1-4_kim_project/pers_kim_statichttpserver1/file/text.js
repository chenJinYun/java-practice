
function changeColor(){
    document.getElementsByTagName("body")[0].style.backgroundColor="black";
}