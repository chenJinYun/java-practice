package pers.kim.decolartor;

public class Hurman extends Intelligentar{

	@Override
	public void walk() {
		// TODO Auto-generated method stub
		System.out.println("human run");
	}

}
