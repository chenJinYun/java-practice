package pers.kim.decolartor;

public abstract class Intelligentar {
	public abstract void walk();
}
